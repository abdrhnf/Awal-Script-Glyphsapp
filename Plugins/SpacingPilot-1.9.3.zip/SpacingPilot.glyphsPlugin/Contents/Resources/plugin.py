from __future__ import division, print_function, unicode_literals

import os
import sys
import traceback

import objc
from Foundation import NSBundle
from GlyphsApp import Glyphs, GLYPH_MENU
from GlyphsApp.plugins import GeneralPlugin


class SpacingPilot(GeneralPlugin):

    @objc.python_method
    def settings(self):
        self.name = Glyphs.localize({'en': 'Spacing Pilot', 'id': 'Spacing Pilot', 'de': 'Spacing Pilot'})

    @objc.python_method
    def start(self):
        resources = NSBundle.bundleForClass_(self.__class__).resourcePath()
        if resources not in sys.path:
            sys.path.insert(0, resources)
        vendor = os.path.join(resources, 'vendor')
        try:
            import vanilla
        except ImportError:
            if os.path.isdir(vendor) and vendor not in sys.path:
                sys.path.append(vendor)
        from GlyphsApp.UI import MenuItem
        self.menuItem = MenuItem(self.name, action=self.showWindow_, target=self)
        Glyphs.menu[GLYPH_MENU].append(self.menuItem)

    def showWindow_(self, sender):
        try:
            from spacing_pilot import license_client
            if not license_client.authorize():
                return
            from spacing_pilot import app
            app.show(reuse=True, preauthorized=True)
        except Exception:
            print(traceback.format_exc())
            Glyphs.showMacroWindow()
